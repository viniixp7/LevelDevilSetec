var gameStarted = false;
var gameCompleted = false;
var scene, camera, renderer;
var currentLevelIndex = 0;
var deathsCount = 0;
var elapsedTime = 0;

const player = {
    position: new THREE.Vector3(0, 2, 0),
    velocity: new THREE.Vector3(0, 0, 0),
    width: 0.9,
    height: 1.4,
    onGround: false,
    startSpawn: new THREE.Vector3(0, 2, 0),
    mesh: null
};

const keys = {
    left: false,
    right: false,
    jump: false,
    jumpPressed: false
};

function resetKeys() {
    keys.left = false;
    keys.right = false;
    keys.jump = false;
    keys.jumpPressed = false;
}

var levelPlatforms = [];
var levelHazards = [];
var levelPortal = null;
var levelTraps = [];

function initFloatingBackgroundLogos() {
    const container = document.getElementById('logo-float-container');
    if (!container) return;
    container.innerHTML = '';

    const count = 12;
    for (let i = 0; i < count; i++) {
        const logo = document.createElement('img');
        logo.src = 'logo.png';
        logo.className = 'floating-logo-bg';
        logo.style.left = (Math.random() * 90 + 5) + 'vw';
        logo.style.top = (Math.random() * 85 + 5) + 'vh';
        const size = Math.random() * 30 + 30;
        logo.style.width = size + 'px';
        logo.style.height = size + 'px';
        logo.style.animationDuration = (Math.random() * 3 + 3) + 's';
        logo.style.animationDelay = Math.random() * 2 + 's';
        container.appendChild(logo);
    }
}

function showFloatingLogos(show) {
    const container = document.getElementById('logo-float-container');
    if (!container) return;
    if (show) container.classList.remove('hidden');
    else container.classList.add('hidden');
}

function showBackgroundVideo(show) {
    const video = document.getElementById('bg-video-element');
    if (!video) return;
    if (show) {
        video.classList.remove('hidden');
        video.play();
    } else {
        video.pause();
        video.classList.add('hidden');
    }
}

function setupPingPongVideo() {
    const video = document.getElementById('bg-video-element');
    if (!video) return;
    video.play();
}

function updateControlsHUDToArrows() {
    const controlContainers = document.querySelectorAll('.glass-panel');
    controlContainers.forEach(el => {
        if (el.innerText.includes('WASD') || el.innerText.includes('Mover') || el.innerText.includes('Pulo')) {
            el.innerHTML = `
                <div class="flex items-center gap-3 text-white font-orbitron text-sm font-semibold">
                    <span class="bg-cyan-500/20 border border-cyan-500/40 px-3 py-1 rounded-md">←</span>
                    <span class="bg-cyan-500/20 border border-cyan-500/40 px-3 py-1 rounded-md">→</span>
                    <span>Mover</span>
                    <span class="ml-4 bg-cyan-500/20 border border-cyan-500/40 px-3 py-1 rounded-md">↑</span>
                    <span>Pular</span>
                </div>
            `;
        }
    });
}

function generate25DevilLevels() {
    const levels = [];
    const platColors = [
        0xffffff, 0x38bdf8, 0xf59e0b, 0xa855f7, 0xf43f5e,
        0x10b981, 0xe2e8f0, 0xf97316, 0x06b6d4, 0xec4899
    ];

    for (let i = 0; i < 25; i++) {
        const levelNum = i + 1;
        const colorIndex = i % platColors.length;

        levels.push({
            name: `${levelNum} — DEVIL LEVEL`,
            build: () => {
                let startX = -12;
                let currentX = startX;
                let spawn = new THREE.Vector3(startX, 2, 0);

                const totalPlatforms = 4 + Math.floor(i * 0.4);

                addPlatform(currentX, 0, 0, 5.5, 1.5, platColors[colorIndex]);
                currentX += 5.5 / 2;

                for (let p = 0; p < totalPlatforms; p++) {
                    const heightVariation = Math.sin(p * 1.2 + i) * 1.2;
                    const platY = Math.max(0, heightVariation);
                    
                    const gap = 3.6 + Math.min(Math.abs(Math.cos(p + i) * 0.6), 0.6);
                    currentX += gap;

                    const platWidth = Math.max(3.2, 4.5 - (i * 0.04));
                    const plat = addPlatform(currentX, platY, 0, platWidth, 1.5, platColors[colorIndex]);

                    if (i === 0) {
                        if (p === 1) createRisingSpikeTrap(currentX, platY, currentX - 2.8);
                    } else if (i === 1) {
                        if (p === 1) {
                            levelTraps.push({ type: 'falling_platform', mesh: plat.mesh, box: plat.box, triggered: false, triggerX: currentX - 2.2 });
                        }
                    } else if (i === 2) {
                        if (p % 2 === 1) createRisingSpikeTrap(currentX, platY, currentX - 2.8);
                    } else {
                        const trapSelector = (p + i * 3) % 4;

                        if (trapSelector === 0) {
                            createRisingSpikeTrap(currentX, platY, currentX - 2.6);
                        } else if (trapSelector === 1) {
                            levelTraps.push({
                                type: 'falling_platform',
                                mesh: plat.mesh,
                                box: plat.box,
                                triggered: false,
                                triggerX: currentX - 2.2
                            });
                        } else if (trapSelector === 2 && i >= 5) {
                            const ceiling = addPlatform(currentX, platY + 8.5, 0, 3.2, 2, 0x18181b);
                            levelTraps.push({
                                type: 'falling_ceiling',
                                mesh: ceiling.mesh,
                                box: ceiling.box,
                                triggered: false,
                                triggerX: currentX - 2.2
                            });
                        }
                    }

                    currentX += platWidth / 2;
                }

                currentX += 4.5;
                addPlatform(currentX, 2, 0, 6, 1.5, 0x10b981);
                addPortal(currentX, 2.75, 0);

                const mapWidth = currentX - startX + 60;
                addHazard(startX + mapWidth / 2, -12, 0, mapWidth * 2, 2, 0x18181b);

                return spawn;
            }
        });
    }
    return levels;
}

function createRisingSpikeTrap(x, platY, triggerX) {
    const hiddenY = platY - 0.2;
    const targetY = platY + 1.25;
    const spike = addSpikeHazard(x, hiddenY, 0, 1.4, 1.0, 0x18181b);

    levelTraps.push({
        type: 'rising_spike',
        hazard: spike,
        currentY: hiddenY,
        targetY: targetY,
        triggered: false,
        triggerX: triggerX
    });
}

const MAP_DEFINITIONS = generate25DevilLevels();

function resetRun() {
    deathsCount = 0;
    elapsedTime = 0;
    document.getElementById('hud-deaths').innerText = "0";
    document.getElementById('hud-timer').innerText = "00:00.000";
}

function loadLevel(index) {
    currentLevelIndex = index;
    const def = MAP_DEFINITIONS[index];
    
    scene.background = new THREE.Color(0x0284c7);

    clearCurrentLevel();

    const spawnPos = def.build();
    player.position.copy(spawnPos);
    player.startSpawn.copy(spawnPos);
    player.velocity.set(0, 0, 0);

    if (player.mesh) player.mesh.position.copy(player.position);

    document.getElementById('hud-level').innerText = `${index + 1}/25`;

    const chkElement = document.getElementById('hud-checkpoints');
    if (chkElement && chkElement.parentElement) {
        chkElement.parentElement.style.display = 'none';
    }

    showToast(`Fase ${def.name} Carregada!`);
}

class SoundFX {
    constructor() { this.ctx = null; }
    init() { if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)(); }
    playJump() {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
        osc.frequency.setValueAtTime(200, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(500, this.ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.1);
        osc.connect(gain); gain.connect(this.ctx.destination);
        osc.start(); osc.stop(this.ctx.currentTime + 0.1);
    }
    playDeath() {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(50, this.ctx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.3);
        osc.connect(gain); gain.connect(this.ctx.destination);
        osc.start(); osc.stop(this.ctx.currentTime + 0.3);
    }
}
const sfx = new SoundFX();

function addPlatform(x, y, z, w, h, colorHex) {
    const geo = new THREE.BoxGeometry(w, h, 2);
    const mat = new THREE.MeshStandardMaterial({ color: colorHex, roughness: 0.3 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    scene.add(mesh);

    const plat = { mesh: mesh, box: new THREE.Box3().setFromObject(mesh) };
    levelPlatforms.push(plat);
    return plat;
}

function addHazard(x, y, z, w, h, colorHex) {
    const geo = new THREE.BoxGeometry(w, h, 2);
    const mat = new THREE.MeshBasicMaterial({ color: colorHex });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    scene.add(mesh);
    const hzd = { mesh: mesh, box: new THREE.Box3().setFromObject(mesh) };
    levelHazards.push(hzd);
    return hzd;
}

function addSpikeHazard(x, y, z, sizeX, sizeY, colorHex) {
    const geo = new THREE.ConeGeometry(0.45, sizeY, 4);
    const mat = new THREE.MeshStandardMaterial({ color: colorHex, roughness: 0.8 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    scene.add(mesh);
    const hzd = { mesh: mesh, box: new THREE.Box3().setFromObject(mesh) };
    levelHazards.push(hzd);
    return hzd;
}

function addPortal(x, y, z) {
    const group = new THREE.Group();

    const innerGeo = new THREE.BoxGeometry(1.6, 2.2, 0.4);
    const innerMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    innerMesh.position.set(0, 0, 0);
    group.add(innerMesh);

    const frameMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.4 });
    
    const leftPillar = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.6, 0.5), frameMat);
    leftPillar.position.set(-1.0, 0, 0);
    group.add(leftPillar);

    const rightPillar = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.6, 0.5), frameMat);
    rightPillar.position.set(1.0, 0, 0);
    group.add(rightPillar);

    const topBar = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.4, 0.5), frameMat);
    topBar.position.set(0, 1.3, 0);
    group.add(topBar);

    const stepTop = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.2, 0.5), frameMat);
    stepTop.position.set(0, 1.6, 0);
    group.add(stepTop);

    group.position.set(x, y + 1.3, z);
    scene.add(group);

    levelPortal = { 
        mesh: group, 
        pos: new THREE.Vector3(x, y + 1.3, z) 
    };
}

function clearCurrentLevel() {
    levelPlatforms.forEach(p => scene.remove(p.mesh));
    levelHazards.forEach(h => scene.remove(h.mesh));
    if (levelPortal) scene.remove(levelPortal.mesh);

    levelPlatforms = [];
    levelHazards = [];
    levelTraps = [];
    levelPortal = null;
}

function showToast(msg) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast glass-panel px-6 py-3 rounded-full text-sm font-orbitron font-semibold text-cyan-300 shadow-xl border border-cyan-500/30';
    toast.innerText = msg;
    container.appendChild(toast);
    setTimeout(() => { if (container.contains(toast)) container.removeChild(toast); }, 3000);
}

function initEngine() {
    setupPingPongVideo();
    initFloatingBackgroundLogos();

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);

    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game-canvas'), antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.0);
    dirLight.position.set(0, 20, 20);
    scene.add(dirLight);

    const playerGeo = new THREE.BoxGeometry(player.width, player.height, 0.8);
    const playerMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.5 });
    player.mesh = new THREE.Mesh(playerGeo, playerMat);
    scene.add(player.mesh);

    window.addEventListener('keydown', (e) => {
        if (e.code === 'KeyA' || e.code === 'ArrowLeft') keys.left = true;
        if (e.code === 'KeyD' || e.code === 'ArrowRight') keys.right = true;
        if (e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp') {
            if (!keys.jump) keys.jumpPressed = true;
            keys.jump = true;
        }
    });

    window.addEventListener('keyup', (e) => {
        if (e.code === 'KeyA' || e.code === 'ArrowLeft') keys.left = false;
        if (e.code === 'KeyD' || e.code === 'ArrowRight') keys.right = false;
        if (e.code === 'Space' || e.code === 'KeyW' || e.code === 'ArrowUp') keys.jump = false;
    });

    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    document.getElementById('btn-enter')?.addEventListener('click', () => {
        sfx.init();
        document.getElementById('splash-screen').classList.add('hidden');
        document.getElementById('start-menu').classList.remove('hidden');
    });

    document.getElementById('btn-start')?.addEventListener('click', () => {
        sfx.init();
        document.getElementById('start-menu').classList.add('hidden');
        
        showBackgroundVideo(false);
        showFloatingLogos(false);

        document.getElementById('hud-overlay').classList.remove('hidden');
        updateControlsHUDToArrows();

        gameStarted = true;
        resetRun();
        loadLevel(0);
    });

    document.getElementById('btn-menu')?.addEventListener('click', (e) => {
        e.stopPropagation();
        gameStarted = false;
        gameCompleted = false;
        resetRun();
        
        showBackgroundVideo(true);
        showFloatingLogos(true);

        document.getElementById('pause-menu')?.classList.add('hidden');
        document.getElementById('hud-overlay')?.classList.add('hidden');
        document.getElementById('start-menu')?.classList.add('hidden');
        document.getElementById('splash-screen')?.classList.remove('hidden');
    });
}

function updatePhysics(delta) {
    if (!gameStarted || gameCompleted) return;

    const gravity = 32.0;
    const speed = 11.0;

    player.velocity.x = 0;
    if (keys.left) player.velocity.x = -speed;
    if (keys.right) player.velocity.x = speed;

    player.velocity.y -= gravity * delta;

    if (keys.jumpPressed) {
        keys.jumpPressed = false;
        if (player.onGround) {
            player.velocity.y = 13.5;
            player.onGround = false;
            sfx.playJump();
        }
    }

    player.position.x += player.velocity.x * delta;
    player.position.y += player.velocity.y * delta;
    player.mesh.position.copy(player.position);

    camera.position.x = player.position.x + 4;
    camera.position.y = 4;
    camera.position.z = 22;
    camera.lookAt(player.position.x + 4, 3, 0);

    player.onGround = false;
    const playerBox = new THREE.Box3().setFromObject(player.mesh);

    levelTraps.forEach(trap => {
        if (!trap.triggered && player.position.x >= trap.triggerX) {
            trap.triggered = true;
        }

        if (trap.triggered) {
            if (trap.type === 'rising_spike') {
                if (trap.currentY < trap.targetY) {
                    trap.currentY += 28 * delta;
                    trap.hazard.mesh.position.y = Math.min(trap.currentY, trap.targetY);
                    trap.hazard.box.setFromObject(trap.hazard.mesh);
                }
            }
            if (trap.type === 'falling_platform') {
                trap.mesh.position.y -= 16 * delta;
                trap.box.setFromObject(trap.mesh);
            }
            if (trap.type === 'falling_ceiling') {
                trap.mesh.position.y -= 26 * delta;
                trap.box.setFromObject(trap.mesh);
            }
        }
    });

    for (let p of levelPlatforms) {
        if (playerBox.intersectsBox(p.box)) {
            const diffX = player.position.x - p.mesh.position.x;
            const diffY = player.position.y - p.mesh.position.y;

            const halfW = (p.box.max.x - p.box.min.x) / 2;
            const halfH = (p.box.max.y - p.box.min.y) / 2;

            const overlapX = halfW + (player.width / 2) - Math.abs(diffX);
            const overlapY = halfH + (player.height / 2) - Math.abs(diffY);

            if (overlapY < overlapX) {
                if (diffY > 0 && player.velocity.y <= 0) {
                    player.position.y = p.box.max.y + (player.height / 2);
                    player.velocity.y = 0;
                    player.onGround = true;
                } else if (diffY < 0 && player.velocity.y > 0) {
                    player.position.y = p.box.min.y - (player.height / 2);
                    player.velocity.y = 0;
                }
            } else {
                player.position.x += Math.sign(diffX) * overlapX;
                player.velocity.x = 0;
            }
        }
    }

    for (let h of levelHazards) {
        if (playerBox.intersectsBox(h.box)) {
            deathsCount++;
            sfx.playDeath();
            
            loadLevel(currentLevelIndex);
            
            document.getElementById('hud-deaths').innerText = deathsCount;
            showToast("Trolado! Voltando ao início...");
            break;
        }
    }

    if (levelPortal && player.position.distanceTo(levelPortal.pos) < 1.6) {
        if (currentLevelIndex + 1 < MAP_DEFINITIONS.length) {
            loadLevel(currentLevelIndex + 1);
        } else {
            gameCompleted = true;
            document.getElementById('victory-screen').classList.remove('hidden');
        }
    }
}

function updateHUD(delta) {
    if (!gameStarted || gameCompleted) return;
    elapsedTime += delta * 1000;
    const totalSeconds = Math.floor(elapsedTime / 1000);
    const mins = String(Math.floor(totalSeconds / 60)).padStart(2, '0');
    const secs = String(totalSeconds % 60).padStart(2, '0');
    const ms = String(Math.floor(elapsedTime % 1000)).padStart(3, '0');
    document.getElementById('hud-timer').innerText = `${mins}:${secs}.${ms}`;
}

var lastTime = performance.now();

function animate() {
    requestAnimationFrame(animate);
    const now = performance.now();
    const delta = Math.min((now - lastTime) / 1000, 0.033);
    lastTime = now;

    updatePhysics(delta);
    updateHUD(delta);

    renderer.render(scene, camera);
}

window.addEventListener('DOMContentLoaded', () => {
    initEngine();
    animate();
});